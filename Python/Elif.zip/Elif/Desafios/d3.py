n = int(input("Digite um número: "))

if n % 2 == 0:
    print("O número é par!")
else:
    print("O número é ímpar!")