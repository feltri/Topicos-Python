a = float(input("Digite o comprimento da reta 1: "))
b = float(input("Digite o comprimento da reta 2: "))
c = float(input("Digite o comprimento da reta 3: "))

if (a+b > c) and (a+c > b) and (b+c > a):
    print("Forma um triângulo")
else:
    print("Não forma um triângulo")