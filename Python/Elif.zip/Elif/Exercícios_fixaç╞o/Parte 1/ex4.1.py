n = int(input("Digite seu ano de nascimento: "))
m = 2024 - n

if m >= 18:
    print("Você é maior de idade!")
else:
    print("Você é menor de idade!")